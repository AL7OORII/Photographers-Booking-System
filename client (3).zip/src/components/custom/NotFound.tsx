interface NotFoundProps {}
const NotFound: React.FC<NotFoundProps> = () => {
  return <div>NotFound</div>;
};

export default NotFound;
