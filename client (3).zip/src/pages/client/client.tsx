
const ClientProfilePage = () => {
  return (
    <div>client</div>
  )
}

export default ClientProfilePage