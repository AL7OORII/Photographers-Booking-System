const config = {
  key: {
    user: "___@photography_user",
    register_email: "___@register_email",
    timeout: "___@timeout",
    isLoggedIn: "___@photography_isLoggedIn",
    expiresAt: "___@photography_expiresAt",
    token: "___@photography_token",
    role: "___@photography_role",
    first_name: "___@photography_first_name",
    last_name: "___@photography_last_name",
    user_id: "___@photography_user_id",
    redirect: "___@photography_redirect",
  },
};

export default config;
